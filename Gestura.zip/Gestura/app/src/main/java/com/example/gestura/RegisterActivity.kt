package com.example.gestura

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        db = DatabaseHelper(this)
        val email = findViewById<EditText>(R.id.txtEmail)
        val username = findViewById<EditText>(R.id.txtUsername)
        val password = findViewById<EditText>(R.id.txtPassword)
        val registerBtn = findViewById<Button>(R.id.btnRegister)

        val btnBack = findViewById<Button>(R.id.btnBack)
        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        registerBtn.setOnClickListener {

            val success = db.registerUser(
                email.text.toString(),
                username.text.toString(),
                password.text.toString()
            )

            if (success) {

                Toast.makeText(
                    this,
                    "Registered Successfully",
                    Toast.LENGTH_SHORT
                ).show()

                finish()

            } else {

                Toast.makeText(
                    this,
                    "Username already exists",
                    Toast.LENGTH_SHORT
                ).show()

            }

        }
    }
}