package com.example.gestura

data class User(
    var id: Int,
    var email: String,
    var username: String,
    var password: String,
    var role: String
)