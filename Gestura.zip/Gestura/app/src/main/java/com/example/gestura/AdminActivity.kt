package com.example.gestura

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper
    lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        db = DatabaseHelper(this)

        listView = findViewById(R.id.listView)

        loadUsers()
        val btnLogout = findViewById<Button>(R.id.btnLogout)
        btnLogout.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        listView.setOnItemClickListener { _, _, position, _ ->

            val user = db.getAllUsers()[position]

            db.deleteUser(user.id, user.role)
            if(user.role=="admin"){
                Toast.makeText(
                    this,
                    "Admin cant be deleted",
                    Toast.LENGTH_SHORT
                ).show()
            }
            else{
                Toast.makeText(
                    this,
                    "User Deleted",
                    Toast.LENGTH_SHORT
                ).show()
                loadUsers()
            }
        }
    }
    private fun loadUsers() {
        val users = db.getAllUsers()
        val names = users.map {
            "${it.username} - ${it.role}"
        }
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            names
        )
        listView.adapter = adapter
    }
}