package com.example.gestura

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        db = DatabaseHelper(this)

        val email = findViewById<EditText>(R.id.txtEmail)
        val username = findViewById<EditText>(R.id.txtUsername)
        val password = findViewById<EditText>(R.id.txtPassword)
        val loginBtn = findViewById<Button>(R.id.btnLogin)

        loginBtn.setOnClickListener {
            val role = db.checkUser(
                email.text.toString(),
                username.text.toString(),
                password.text.toString()
            )
            if (role != null) {
                if (role == "admin") {
                    val intent = Intent(this, AdminActivity::class.java)
                    startActivity(intent)
                } else {
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                }

            } else {
                Toast.makeText(
                    this,
                    "Invalid Username or Password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val btnMain = findViewById<Button>(R.id.btnMain)
        btnMain.setOnClickListener {
            val main = Intent(this, MainActivity::class.java)
            startActivity(main)
        }
    }
}