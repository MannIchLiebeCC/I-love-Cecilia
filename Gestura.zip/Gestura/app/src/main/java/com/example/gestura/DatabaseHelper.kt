package com.example.gestura

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "GesturaDB", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE,
                username TEXT UNIQUE,
                password TEXT,
                role TEXT
            )
        """
        db.execSQL(createTable)
        val values = ContentValues()
        values.put("email", "admin@gmail.com")
        values.put("username", "admin1")
        values.put("password", "admin123")
        values.put("role", "admin")
        db.insert("users", null, values)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }
    fun registerUser(email: String, username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("email", email)
        values.put("username", username)
        values.put("password", password)
        values.put("role", "user")
        val result = db.insert("users", null, values)
        return result != -1L
    }
    fun checkUser(email: String, username: String, password: String): String? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT role FROM users WHERE email=? AND username=? AND password=?",
            arrayOf(email, username, password)
        )
        return if (cursor.moveToFirst()) {
            cursor.getString(0)
        } else {
            null
        }
    }
    fun getAllUsers(): ArrayList<User> {
        val list = ArrayList<User>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users", null)
        while (cursor.moveToNext()) {

            val user = User(
                cursor.getInt(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4)
            )
            list.add(user)
        }
        return list
    }
    fun deleteUser(id: Int, role: String) {
        val db = writableDatabase
        if(role!="admin"){
            db.delete("users", "id=?", arrayOf(id.toString()))
        }
    }

}